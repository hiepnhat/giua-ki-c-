#include "SanPham.h"
#include "ListSanPham.h"
#include <iostream>

using namespace std;
 
void ListSanPham::inputList(){
	int i, soLuong;
	string ma, ten;
	double donGia, thanhTien;
	n=2;
	for(i=0; i<n; i++){
		cout << "Nhap thong tin san pham thu " << i << ": \n";
		cout << "Nhap ma san pham: "; cin >> ma;
		cout << "\nNhap ten san pham: "; cin >> ten;
		cout <<"\nNhap so luong: "; cin >> soLuong;
		cout << "\nNhap don gia: "; cin >> donGia;
		sp[i].setMa(ma);
		sp[i].setTen(ten);
		sp[i].setSoLuong(soLuong);
		sp[i].setDonGia(donGia);
		sp[i].setThanhTien(thanhTien);
	}		
};

void ListSanPham::outputList(){
	int i;
	cout <<"In thong tin san pham: "<<endl; 
	   for(i=0;i<n; i++){
	   	 cout <<"San pham "<<i<<": ("<<sp[i].getMa()<<", " << sp[i].getTen() << ", " << sp[i].getSoLuong() << ", " << sp[i].getDonGia() << ", " << sp[i].getThanhTien() << ")"<<endl;	 
	   	// cout <<"San pham "<<i<<": ("<<sp[i].getMa()<<", " << sp[i].getTen() << ", " << sp[i].getSoLuong() << ", " << sp[i].getDonGia() << ")"<<endl;
	   }
};
//void ListPoint::lenList(){
//	   int i,l,d=0;
//	   for (i=1;i<n;i++){
//	   		l=sqrt((p[i].getX()-p[i-1].getX())*(p[i].getX()-p[i-1].getX())
//	   			  +(p[i].getY()-p[i-1].getY())*(p[i].getY()-p[i-1].getY()));
//	   		d+=l;
//	   }
//	   cout<<"Do dai d="<<d<<endl;
//};
//
//void ListPoint::maxLen(){
//	int i,l, pos; double max;
//	max=0;  pos=0;
//   for (i=1; i<n;i++){
//   	  l=sqrt((p[i].getX()-p[i-1].getX())*(p[i].getX()-p[i-1].getX())
//   	        +(p[i].getY()-p[i-1].getY())*(p[i].getY()-p[i-1].getY()));
//      if (max<l){
//      	max=l;    	pos=i;
//      }
//   }	  
//   cout <<"Max="<<max<<" tai doan P"<<pos<<pos-1<<endl;
//};



