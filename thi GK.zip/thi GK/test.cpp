#include "SanPham.h"
#include "ListSanPham.h"
#include <iostream>

using namespace std;
 
int main() {
	 
     ListSanPham listSP;
	 listSP.inputList();
	 listSP.outputList();
//	 listP.lenList();
//	 listP.maxLen();	
}
