#include "SanPham.h"
#include <iostream>

/*SanPham::SanPham(string ma, int sl, double donGia, double tt){
	this -> ma = ma;
	this -> donGia = donGia;
	this -> thanhTien = tt;
}*/

SanPham::SanPham(){
}

string SanPham::getMa() const{
	return ma;
}

void SanPham::setMa(string m){
	this -> ma = m;
}

string SanPham::getTen() const{
	return ten;
}

void SanPham::setTen(string ten){
	this -> ten = ten;
}

int SanPham::getSoLuong() const{
	return soLuong;
}

void SanPham::setSoLuong(int sl){
	this -> soLuong = sl;
}

double SanPham::getDonGia() const{
	return donGia;
}

void SanPham::setDonGia(int donGia){
	this -> donGia = donGia;
}

double SanPham::getThanhTien() const{
	return thanhTien;
}

void SanPham::setThanhTien(double thanhTien){
	this -> thanhTien = thanhTien;
}

