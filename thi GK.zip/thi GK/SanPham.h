#ifndef SANPHAM_H   
#define SANPHAM_H  
#include <string> 
using namespace std;

class SanPham{
	private:
		string ma;
		string ten;
		int soLuong;
		double donGia;
		double thanhTien;
	public:
		//SanPham(string ma, int sl, double donGia, double tt);
		SanPham();
		string getMa() const;
		void setMa(string m);
		string getTen() const;
		void setTen(string ten);
		int getSoLuong() const;
		void setSoLuong(int sl);
		double getDonGia() const;
		void setDonGia(int donGia);
		double getThanhTien() const;
		void setThanhTien(double thanhTien);
};

#endif
