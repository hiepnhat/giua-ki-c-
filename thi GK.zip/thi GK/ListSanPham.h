#ifndef LISTSANPHAM_H
#define LISTSANPHAM_H
#include "SanPham.h"

class ListSanPham{
private:
   int n;
   SanPham sp[2];  
 
public:
   ListSanPham(){n=0;};; 
   void inputList();
   void outputList() ;
//   void lenList();
//   void maxLen();
};
#endif
